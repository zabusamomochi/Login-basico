function btn(){
    let email = document.getElementById("email").value;
    let senha = document.getElementById("senha").value;

    if(email == "daniel@hotmail.com" && senha == "123"){
        alert("senha correta!");
    }else{
        alert("Usuário ou senha incorretos");
    }
}